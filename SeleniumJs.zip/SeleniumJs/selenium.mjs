import { Builder, By, Key, until } from 'selenium-webdriver';

function first() {
    // Create a new instance of the Firefox driver

    try {
        driver.manage().setTimeouts({ implicit: 10000 }); // Set implicit wait time to 10 seconds

        driver.manage().window().maximize(); // Maximize the window

        // Navigate to the page
        driver.get('https://google.com/');

        let close_button = driver.findElement(By.className("cky-banner-btn-close"));
        close_button.click(); // Click the close button

        // Wait for the element to be present
        let first_element = driver.wait(until.elementLocated(By.class("gLFyf")));
        first_element = driver.findElement(By.class("gLFyf"));
        first_element.sendKeys("Where is MTN head office?");// Click the first element
        first_element = Key.ENTER();


        // Perform actions on the element
         element.click();
    } catch (error) {
        console.error('Error:', error);
    } finally {
        // Quit the driver
         driver.quit();
    }
}

first();