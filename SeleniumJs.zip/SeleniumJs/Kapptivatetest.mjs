describe("test1", function() {

    // This ensures browser is ready before tests
  before(function() {
      it("Open mtn.com.gh", function(){
        browser.url("https://mtn.com.gh");
      });
    
    it("Click on the close button on the pop-up", function() {
    let elem = $(".cky-banner-btn-close");

    // Wait for button to be visible & clickable
   if ( elem.waitForDisplayed()){
    elem.waitForClickable();
    
    // Click the close button
    elem.click();
       
   } else {
       console.log("Close button not found - Skipping.");
       
   }
  });
  });
  });