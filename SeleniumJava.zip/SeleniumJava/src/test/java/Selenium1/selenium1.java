package Selenium1;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.time.Duration;

public class selenium1 {

    public static void main(String[] args){

        /*
        Initializing the webdriver
         */
        WebDriver web = new ChromeDriver();

        //Opening the url for testing.
        web.get("https://mtn.com.gh/");

        web.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        String title = web.getTitle();

        if (title.equals(title)){
            System.out.println("Passed");
        }
        else {
            System.out.println("Failed");
        }
        try {
            WebElement close = web.findElement(By.className("cky-banner-btn-close"));
            if (close.isDisplayed()){
                close.click();
            }
        }catch (NoSuchElementException e){
            System.out.println("Failed to find the close pop-up button");
        }

        WebElement explore = web.findElement(By.linkText("Explore"));
        explore.click();


        WebElement help_button = web.findElement(By.partialLinkText("Help"));
        help_button.click();
    }

}

