# appium_test_tutorials

Project with .venv, requirements.txt, and src/main.py.
