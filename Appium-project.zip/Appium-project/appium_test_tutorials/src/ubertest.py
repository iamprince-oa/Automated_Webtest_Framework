from appium import webdriver
from appium.options.android import UiAutomator2Options

# Set up desired capabilities and pass the Android app-activity and app-package to Appium
options = UiAutomator2Options()
options.platformName = "Android"
options.deviceName = "1B271FDF6007B8"
options.automationName = "UiAutomator2"
options.appPackage = "com.ubercap"
options.appActivity = "" \
"com.ubercab/com.ubercab.presidio.app.core.root.RootActivity"
options.autoGrantPermissions = True
options.app = r"C:\Users\owusu\Desktop\uber.apk"

# Initialize the driver
app = webdriver.Remote("http://localhost:4723", options=options)

#Wait time
app.implicitly_wait(20)

