from appium import webdriver
from appium.options.android import UiAutomator2Options

# Set up desired capabilities and pass the Android app-activity and app-package to Appium
options = UiAutomator2Options()
options.platformName = "Android"
options.deviceName = "1B271FDF6007B8"
options.automationName = "UiAutomator2"
options.appPackage = "com.github.android"
options.appActivity = "com.google.android.deskclock/android.service.dreams.DreamActivity"
options.autoGrantPermissions = True
options.app = "C:\\Users\\owusu\\Desktop\\github.apk"

# Initialize the driver
app = webdriver.Remote("http://localhost:4723", options=options)

#Wait time
#app.implicitly_wait(30)

# Find the first action button and click on it
